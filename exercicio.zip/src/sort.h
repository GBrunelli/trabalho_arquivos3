#ifndef SORT_H
#define SORT_H

void sortCars(void);
void sortLines(void);


#endif